#!/bin/bash
# Automatische Bildoptimierung ohne Userinput
WATCH_DIR="/media/sf_Compare/Bildoptimierung"
OUTPUT_DIR="$WATCH_DIR/optimized"

mkdir -p "$OUTPUT_DIR"
inotifywait -m "$WATCH_DIR" -e create -e moved_to --format '%w%f' | while read filepath; do
  filename=$(basename "$filepath")
  if [[ "$filename" =~ \.(jpg|jpeg|png)$ ]]; then
    echo "📷 Optimierung: $filename"
    convert "$filepath" -resize 50% "$OUTPUT_DIR/optimized_$filename"
    echo "✅ Gespeichert in: $OUTPUT_DIR"
  fi
done
