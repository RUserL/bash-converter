#!/bin/bash
# Vergleich von zwei PDF-Dateien (automatisch)
# Beispiel: ./compare.sh -1 compare1.pdf -2 compare2.pdf

while getopts 1:2: flag; do
  case "${flag}" in
    1) file1=${OPTARG} ;;
    2) file2=${OPTARG} ;;
  esac
done

if diff -q "$file1" "$file2" > /dev/null; then
  echo "✅ Dateien sind gleich"
else
  echo "❌ Dateien unterscheiden sich"
fi
