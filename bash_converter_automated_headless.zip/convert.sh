#!/bin/bash
# Automatische Konvertierung
# Beispielaufruf: ./convert.sh -d /pfad/zur/datei -f pdf -a

while getopts d:f:a flag; do
  case "${flag}" in
    d) directory=${OPTARG} ;;
    f) format=${OPTARG} ;;
    a) auto=true ;;
  esac
done

output_dir="sf_Compare/$(basename "$directory")_$(date +%F)"
mkdir -p "$output_dir"

for file in "$directory"/*; do
  filename=$(basename "$file")
  case "$format" in
    pdf|jpg|png)
      convert "$file" "$output_dir/${filename%.*}.$format"
      ;;
    txt|md)
      pandoc "$file" -o "$output_dir/${filename%.*}.pdf"
      ;;
    *)
      echo "❌ Ungültiges Format"; exit 1 ;;
  esac
done

echo "✅ Konvertierung abgeschlossen: $output_dir"
