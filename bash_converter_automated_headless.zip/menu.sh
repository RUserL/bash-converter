#!/bin/bash

# Headless-Check
if [[ "$1" == "--headless" ]]; then
  echo "🤖 Starte im Headless-Modus..."

  # Beispiel: Automatische Konvertierung starten
  ./convert.sh -d /media/sf_Compare/input -f pdf -a

  # Beispiel: PDF-Vergleich ausführen
  ./compare.sh -1 /media/sf_Compare/compare1.pdf -2 /media/sf_Compare/compare2.pdf

  # Beispiel: Bildoptimierung überwachen
  nohup ./watch.sh > logs/watch.log 2>&1 &

  # Beispiel: Virenscan starten
  ./virus_scan.sh -d /media/sf_Compare > logs/virus_scan.log

  exit 0
fi

# Interaktives Menü (Fallback)
while true; do
  clear
  echo "=== Bash-Konverter Menü ==="
  echo "1) Manuelle Konvertierung"
  echo "2) Automatische Bildoptimierung starten"
  echo "3) PDF-Vergleich starten"
  echo "4) Virenscan im Ordner starten"
  echo "5) Beenden"
  echo "============================"
  read -p "Auswahl: " option

  case $option in
    1) ./convert.sh ;;
    2) ./watch.sh ;;
    3) ./compare.sh ;;
    4) ./virus_scan.sh ;;
    5) echo "Beende..." ; exit 0 ;;
    *) echo "❌ Ungültige Auswahl!" ; sleep 1 ;;
  esac
done
