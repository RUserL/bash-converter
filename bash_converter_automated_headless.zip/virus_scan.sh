#!/bin/bash
# Virenscan automatisiert
# Beispiel: ./virus_scan.sh -d /media/sf_Compare

while getopts d: flag; do
  case "${flag}" in
    d) watch_dir=${OPTARG} ;;
  esac
done

inotifywait -m "$watch_dir" -e create -e moved_to --format '%w%f' | while read filepath; do
  filename=$(basename "$filepath")
  echo "🕵️ Prüfe $filename ..."
  result=$(clamscan "$filepath")
  echo "$result"

  if echo "$result" | grep -q "Infected files: 1"; then
    echo "⚠️ Virus erkannt in $filename!"
  else
    echo "✅ Kein Virus in $filename"
  fi
done
